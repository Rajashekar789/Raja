
##  Angular2 features 

1. Event and properties binding 
2. $event passing as object 
3. Bootstrap link
4. Routing and guard
5. Create model/class
6. Create header component
7. Shared folder purpose 
8. Detail page - Weather on right hand side 
9. OAuth Login integration with local bowser support 
10. Debugging - web pack and type script  though source map debuuging 
11. Component to component binding through input and output declarative 
12. EventEmitter 
13  Type script life cycle and hooks to each phase 
14. Static meesage in entire project 
15. Multilangual - imp
16. Multiple environment - imp
17. Paging control 