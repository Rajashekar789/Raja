export const environment = {
  production: false,
  appId: '45f4dd45e0f724512ba044c5a2caf4bc',
  baseUrl: 'http://api.openweathermap.org/data/2.5/',
  units:'metric'
};
