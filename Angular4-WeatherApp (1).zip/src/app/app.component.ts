import { Component } from '@angular/core';

@Component({
  selector: 'weather-app-root',
  templateUrl: './app.component.html',
 // styleUrls: ['./app.component.css']
 // styleUrls: ['../style.css']
})
export class AppComponent {
  title = 'Angular4, Weather Application';
}
