import { Component, Injectable, OnInit, Pipe, PipeTransform } from '@angular/core';
import {WeatherService} from './weather.service';
// import {Subject} from "rxjs/Subject";
import { Weather } from './weather';


@Component({
    selector: 'weather-search',
    templateUrl: './weather-search.component.html',
    styleUrls: ['./weather-search.component.css']
})
export class WeatherSearchComponent implements OnInit {

    errorMessage: boolean;
    WeatherForecastCity: string;
    weatherForecastDataObject: any;
    weatherForecastData: any;
    disabledForecastButton = true;
    disableFilterOption = false;
    cityName: string;
    entries = [];
    selectedEntry: { [key: string]: any } = {
      value: null,
      description: null
    };
    weatherListDataAll: any;
    weatherListDataCurrent: any;
    weatherListDataWeek: any;
    constructor(private _weatherService: WeatherService) {
    }

    ngOnInit() {

        this.entries = [
            {
              description: 'All',
              id: 1
            },
            {
              description: 'Today',
              id: 2
            },
            {
              description: 'Weekly',
              id: 3
            }
          ];
          if (this.entries) {
            this.onSelectionChange(this.entries[0]);
          }
    }
    onSelectionChange(entry) {
        // clone the object for immutability
        // console.log('entry => ', entry);
        // console.log(this.weatherForecastDataObject, ' weatherForecastData => ', this.weatherForecastData);
        if (this.weatherForecastData) {
          if (entry.id === 2) {
            this.weatherForecastDataObject = this.getweatherListDataCurrentDay( this.weatherForecastData );
          }else if (entry.id === 3) {
            this.weatherForecastDataObject = this.getweatherListDataCurrentWeek( this.weatherForecastData );
          }else {
            this.weatherForecastDataObject = this.weatherForecastData.list;
          }
        }
        this.selectedEntry = Object.assign({}, this.selectedEntry, entry);
    }

    onSubmit(cityName: string) {
      console.log(cityName);
/*    if (this.cityName == null){*/
        this._weatherService.getWeatherForecast(cityName)
         .subscribe(data => {this.weatherForecastData = data},
                    error =>  this.errorMessage = true,
     );
    }
   // }
    onSearchLocation(cityName: string) {
     this.disabledForecastButton = false;
     // console.log(cityName);
    }
    onBackChange() {
        this.disableFilterOption = false;
    }
    onSubmitDatabinding() {
     console.log('inside the two way' + this.cityName);
        this._weatherService.getWeatherForecast(this.cityName)
         .subscribe(data => {
            this.weatherForecastData = data;
            this.WeatherForecastCity = this.weatherForecastData.city.name;
            this.weatherForecastDataObject =  this.weatherForecastData.list;
            this.errorMessage = false;
            this.disableFilterOption = true;
        },
          error =>  this.errorMessage = true,
     );
      this.onResetControls();
    }

    getweatherListDataCurrentDay(foreCastData: any) {
      let currentDate: Date = new Date();
      let strDate: string = currentDate.getFullYear() + '-' + (currentDate.getMonth() + 1) + '-' + currentDate.getDate();
        if (foreCastData) {
          let currentDateArray = this.weatherForecastData.list.filter(item => {
            // console.log(item.dt_txt, '<>',  strDate);
             console.log(item.dt_txt.toString().indexOf(strDate));
            if (item.dt_txt.toString().indexOf(strDate) > -1) {
                return item;
            }
        } );
       // foreCastData.list = currentDateArray;
       return currentDateArray;
      }
    }

    getweatherListDataCurrentWeek(foreCastData: any) {
      // call the api with &cnt=5
      let currentDate: Date = new Date();
      let strDate: string = currentDate.getFullYear() + '-' + (currentDate.getMonth() + 1) + '-' + currentDate.getDate();
        if (foreCastData) {
          let currentDateArray = this.weatherForecastData.list.filter(item => {
            // console.log(item.dt_txt, '<>',  strDate);
             console.log(item.dt_txt.toString().indexOf(strDate));
            if (item.dt_txt.toString().indexOf(strDate) === -1) {
                return item;
            }
        } );
       // foreCastData.list = currentDateArray;
       return currentDateArray;
      }
    }

    onSearchLocationWithEvent(event:Event) {
      // console.log("Complete event data value: "+ event);
      console.log('Control value: ' + (<HTMLInputElement>event.target).value);
      this.cityName = (<HTMLInputElement>event.target).value;
      this.disabledForecastButton = false;
    }

    onResetControls() {
        this.cityName = '';
        this.disabledForecastButton = true;

    }
  }