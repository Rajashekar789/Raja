import {Weather} from "./weather";
export const WEATHER_LIST: Weather[] = [
    new Weather('Japan', 'CLoudy', 34),
    new Weather('China', 'Rainy', 24),
    new Weather('IN', 'Clear', 14),
];

