import { Component, OnInit, Input} from '@angular/core';
import { Weather } from './weather';
import { WeatherService } from './weather.service';
import { Router } from '@angular/router';
import { trigger, state, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'weather-list',
  templateUrl: './weather-list.component.html',
  styleUrls: ['./weather-list.component.css'],
  animations: [
    trigger('flyInOut', [
      state('in', style({opacity: 1, transform: 'translateX(0)'})),
      transition('void => *', [
        style({
          opacity: 0,
          transform: 'translateX(-100%)'
        }),
        animate('1s ease-in')
      ]),
      transition('* => void', [
        animate('0.2s 0.1s ease-out', style({
          opacity: 0,
          transform: 'translateX(100%)'
        }))
      ])
    ])
  ],
  providers: [WeatherService]
})
export class WeatherListComponent implements OnInit {
  @Input('WeatherForecastList') weathers: any;
  @Input('WeatherForecastCity') WeatherForecastCity: any;
  errorMessage: string;
  animationState: string = 'in';
 // weathers: any[];

  constructor(private _weatherService: WeatherService,
              private router: Router) {
    // console.log("WeatherForecastCity => "+this.WeatherForecastCity);
  }

  ngOnInit(): any {
  }
    gotoDetailpage(id: number): any {
      this.router.navigate(['/detail-page', id]);
    }

}
